/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package networkthread;

import java.util.ArrayList;

/**
 *
 * @author mash
 */
public class Constants {
    public String host="localhost";
    public int port = 5555;
    public ArrayList<Server> connections;
    

    /**
     *
     */
    public ArrayList<ArrayList< Server >> friendMatrix;
}
