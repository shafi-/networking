/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package networkthread;

/**
 *
 * @author mash
 */
class StoredFile {
    String From;
    String To;
    int fileName;
    public StoredFile(String from, String to, int filename)
    {
        From = from;
        To = to;
        fileName = filename;
    }
}
